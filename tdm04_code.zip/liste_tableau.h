#pragma once

typedef struct {
	double	*contenu;
	int		*suivant;
	int		p_tete;
	int		p_libre;
} liste_tableau;